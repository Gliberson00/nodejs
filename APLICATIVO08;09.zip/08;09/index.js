const questions = [
     " o que aprendi hoje?",
     " o que me deixou bravo? E o que eu poderia fzaer para melhorar ?",
     "  o que me deixou feliz?",
     " quantas pessoas ajudei hoje ?"

]
const ask = ( index = 0) => {
    process.stdout.write("\n\n" + questions[index] + " > ")
}

ask()

const resposta = []

process.stdin.on("data", data =>{
    resposta.push(data.toString().trim())
    if(resposta.length < questions.length){
        ask(resposta.length)
    }else{
        console.log(resposta)
        process.exit()

    }
    
}) 
process.on('exit', () =>{
    console.log(`
      vlw Gli

      o que vc aprendeu hoje foi:
      ${resposta[0]}

      o te deixou bravo e poderia melhora foi:
      ${resposta[1]}

      o que te deixou feliz foi:
      ${resposta[2]}

      voce ajudou ${resposta[3]} pessoas hoje!!

      volte amanha para nova refelxoes!!
    
    
    `)
    
    
})