const express = require ('express');
const app = express();

// importa roteamentp
const carros = require('./routes/carros');

//config
const PORT = process.env.PORT || 3000;

//MIDDLEWARES
const usuariologado = true;

app.use('/restrita',(req,res,next)=>{
    if(!usuariologado){
        res.redirect('/'); 
    }
    next();

});

app.get('/',(req,res) =>{
    res.send('<h1> Pgina inicial </h1>')
});
app.get('/restrita',(req,res)=>{
    res.send('<h1> ROTA RESTRITA </h1>')

});
app.get('/restrita/usuarios',(req,res)=>{
    res.send('<h1> Lista usuarios </h1>')

});

app.get('/', (req,res)=>{
    res.send(__dirname + './public/index.html');
});

app.get('/sobre', (req,res)=>{
    res.send('<h1> pagina sobre</h1>');
})

app.use('./carros',carros);

//carros/fiat/uno

app.listen(PORT,()=>{
    console.log(`Servidor rodandoo em http://localhost:${PORT}`);
});